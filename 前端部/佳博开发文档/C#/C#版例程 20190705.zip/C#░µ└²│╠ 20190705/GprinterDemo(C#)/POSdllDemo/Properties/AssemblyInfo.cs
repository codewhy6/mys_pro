using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GprinterDEMO")]
[assembly:AssemblyDescription("")]
[assembly:AssemblyConfiguration("")]
[assembly:AssemblyCompany("")]
[assembly: AssemblyProduct("GprinterDEMO")]
[assembly:AssemblyCopyright("Copyright china 2014")]
[assembly:AssemblyTrademark("")]
[assembly:AssemblyCulture("")]


[assembly:ComVisible(false)]

[assembly:Guid("e445b98b-5b51-4b29-994f-f7abe3594a69")]

[assembly:AssemblyVersion("1.0.0.0")]
[assembly:AssemblyFileVersion("1.0.0.0")]
